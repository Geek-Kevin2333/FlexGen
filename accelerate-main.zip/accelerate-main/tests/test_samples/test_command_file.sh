echo "hello world"
echo "this is a second command"