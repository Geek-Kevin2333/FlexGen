---
title: "DeepSpeed: Advancing MoE inference and training to power next-generation AI scale"
excerpt: ""
link: https://www.microsoft.com/en-us/research/blog/deepspeed-advancing-moe-inference-and-training-to-power-next-generation-ai-scale/
date: 2022-01-19 00:00:00
tags: inference
---
