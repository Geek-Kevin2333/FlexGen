---
title: "DeepSpeed powers 8x larger MoE model training with high performance"
excerpt: ""
link: https://www.microsoft.com/en-us/research/blog/deepspeed-powers-8x-larger-moe-model-training-with-high-performance/
date: 2021-08-18 00:00:00
tags: training
---
