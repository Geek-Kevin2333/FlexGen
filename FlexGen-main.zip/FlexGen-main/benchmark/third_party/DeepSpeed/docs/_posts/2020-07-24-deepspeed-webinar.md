---
title: "DeepSpeed Microsoft Research Webinar on August 6th, 2020"
excerpt: ""
tags: presentations
link: https://note.microsoft.com/MSR-Webinar-DeepSpeed-Registration-On-Demand.html
image: /assets/images/webinar-aug2020.png
date: 2020-07-24 00:00:00
---
