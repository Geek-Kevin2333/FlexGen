Mixture of Experts (MoE)
====================

Layer specification
--------------------
.. autoclass:: deepspeed.moe.layer.MoE
    :members:
