'''
Copyright 2022 The Microsoft DeepSpeed Team
'''


class DeprecatedException(Exception):
    pass
