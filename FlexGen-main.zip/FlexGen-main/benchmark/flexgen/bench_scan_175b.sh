python3 -m flexgen.flex_opt --model facebook/opt-175b --path _DUMMY_ --pin-weight 0 --percent 0 100 100 0 100 0 --gpu-batch-size 1 --gen-len 1 --sep-layer 0
