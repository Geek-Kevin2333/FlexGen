


### Network 

- Two a40.1x machine:
  - Delay: cannot ping each other.