source activate base
cd /home/binhang.yuan/fm/new/GPT-home-private

python foo.py