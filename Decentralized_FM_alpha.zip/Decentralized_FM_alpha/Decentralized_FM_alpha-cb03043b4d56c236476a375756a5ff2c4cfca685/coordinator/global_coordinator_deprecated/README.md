# Global Coordinator

### Set up coordinator 

- Install memcache:

        sudo apt-get update
        sudo apt-get install memcached
        sudo apt install python3-pip -y
        pip install pymemcache

- Start memcache:
       
        memcached -p 11111 -U 11111

- Kill memcache:
        
        sudo pkill -9 memcached

        

        

        

