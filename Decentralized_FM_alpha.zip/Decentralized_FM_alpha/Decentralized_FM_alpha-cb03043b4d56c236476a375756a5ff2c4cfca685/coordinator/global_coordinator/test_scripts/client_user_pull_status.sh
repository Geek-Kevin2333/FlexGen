cd ..

python global_user_client.py --op status