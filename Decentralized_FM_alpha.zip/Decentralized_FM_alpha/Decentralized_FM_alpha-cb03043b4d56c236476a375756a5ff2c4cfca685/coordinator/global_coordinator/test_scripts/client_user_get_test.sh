key=$1

cd ..

python global_user_client.py --op get --request-key $key