cd ..

python global_user_client.py --op put --model-name gpt-j-6B --task-type seq_generation --inputs "hello world! How to learn python?"