cd ..

python global_coordinator_server.py --clear-all false --op check_job