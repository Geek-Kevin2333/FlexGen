cd ..

python global_user_client.py --op put --model-name stable_diffusion --task-type image_generation --inputs "A dog with sunglass"