# bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp6.sh 3 2
# sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 4 2
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 5 2
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 3 4
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 4 4
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 5 4
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 3 8
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 4 8
sleep 10s

bash fluidstack_run_gpt3_Ngpu_shuffled_training.sh local_fluidstack_gpt3_pp8_dp4.sh 5 8
sleep 10s