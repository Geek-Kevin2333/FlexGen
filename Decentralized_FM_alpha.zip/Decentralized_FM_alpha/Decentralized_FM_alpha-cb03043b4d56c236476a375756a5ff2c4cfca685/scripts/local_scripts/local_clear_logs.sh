cd ~/GPT-home-private/logs
rm ./*.log
cd ~/GPT-home-private/trace_json
rm ./*.json