cd ~/GPT-home-private/

case=$1
sh ./scripts/tc_scripts/heterogeneous_setup_case"$case".sh