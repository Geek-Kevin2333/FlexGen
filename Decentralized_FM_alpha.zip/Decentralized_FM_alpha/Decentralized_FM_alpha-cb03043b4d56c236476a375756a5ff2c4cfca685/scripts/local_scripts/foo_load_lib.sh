cd ~/GPT-home-private
# source activate pytorch_p38
python3 foo.py