# Generate ssh key (optional)
ssh-keygen

ssh-copy-id -i ~/.ssh/id_rsa.pub fsuser@xx.xx.xx.xx