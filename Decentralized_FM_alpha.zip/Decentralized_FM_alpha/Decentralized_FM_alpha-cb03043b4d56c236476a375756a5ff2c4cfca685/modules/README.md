# Dependencies

- pip install sentencepiece

## GLM

- pip install protobuf==3.20
