from .ice_tokenizer import IceTokenizer

icetk = IceTokenizer()

__all__ = ['icetk']