### Evaluation code for E2E, WebNLG and Dart

* Code for evaluating E2E https://github.com/tuetschek/e2e-metrics
* Code for evaluating WebNLG and Dart https://github.com/WebNLG/GenerationEval.git

Before running evaluation for the first time you must run
`bash download_evalscript.sh`
